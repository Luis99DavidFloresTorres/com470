package com.example.prueba2;

import org.junit.Assert;
import org.junit.Test;

import static com.example.prueba2.PasswordUtil.SecurityLevel.WEAK;

public class PasswordUtilTest {
    PasswordUtil password = new PasswordUtil();
    @Test
    public void testCompruebaPasswordCuandoMenos8Caraceteres(){
        Assert.assertEquals(WEAK,password.compruebaPassword("123456"));
    }
}
