package com.example.prueba2;

import junitparams.JUnitParamsRunner;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;


@RunWith(JUnitParamsRunner.class)
public class FibonacciTest {
    Fibonacci fib = new Fibonacci();

    @Test
    @junitparams.Parameters({"1","3","5"})
    public void testSumaNumeros( int x ){
        String resultado = fib.bibonacci(x);
        String resultado1 = "0,1,1";
        String resultado2 = "0,1,1,2,3";
        String resultado3 = "0,1,1,2,3,5";
        String[] vector = {resultado1,resultado2,resultado3};
        if(x==1){
            Assert.assertEquals(resultado1, resultado);
        }
        if(x==3){
            Assert.assertEquals(resultado2, resultado);
        }
        if(x==5){
            Assert.assertEquals(resultado3, resultado);
        }
    }
}
