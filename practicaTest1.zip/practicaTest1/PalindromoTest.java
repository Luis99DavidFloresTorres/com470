package com.example.prueba2;

import junitparams.JUnitParamsRunner;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(JUnitParamsRunner.class)
public class PalindromoTest {
    Palindromo pal = new Palindromo();
    @Test
    @junitparams.Parameters({"bob","ana"})
    public void testPalindromo( String palabra ){
        boolean resultadoBob = pal.buscaPalindromo("bob");
        boolean resultadoAna = pal.buscaPalindromo("ana");
        if(palabra.equals("bob")){
            Assert.assertEquals(true, resultadoBob);
        }
        if(palabra.equals("ana")){
            Assert.assertEquals(true, resultadoAna);
        }

    }
}
