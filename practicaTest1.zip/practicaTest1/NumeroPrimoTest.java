package com.example.prueba2;

import junitparams.JUnitParamsRunner;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(JUnitParamsRunner.class)
public class NumeroPrimoTest {
    NumeroPrimo primo = new NumeroPrimo();

    @Test
    @junitparams.Parameters({"1","3","5"})
    public void testSumaNumeros( int x ){
       boolean resultado1 = primo.validate(x);

        if(x==1){
            Assert.assertEquals(true, resultado1);
        }
        if(x==3){
            Assert.assertEquals(true, resultado1);
        }
        if(x==5){
            Assert.assertEquals(true, resultado1);
        }
    }
}
