package com.example.prueba2;

import junitparams.JUnitParamsRunner;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(JUnitParamsRunner.class)
public class CalculadoraTest {
    Calculadora calc = new Calculadora();
    @Test
    @junitparams.Parameters({"3,6","2,3","1,7"})
    public void testCalc( int x,int y ){
        int resultadoSuma = calc.suma(x,y);
        int resultadoResta = calc.resta(x,y);
        int resultadoDiv = calc.division(x,y);
        int resultadoMult = calc.multimplicacion(x,y);

        if(x==3){
            Assert.assertEquals(9, resultadoSuma);
            Assert.assertEquals(-3, resultadoResta);
            Assert.assertEquals(18, resultadoMult);
            Assert.assertEquals(3/6, resultadoDiv);
        }
        if(x==2){
            Assert.assertEquals(5, resultadoSuma);
            Assert.assertEquals(-1, resultadoResta);
            Assert.assertEquals(6, resultadoMult);
            Assert.assertEquals(2/3, resultadoDiv);
        }
        if(x==1){
            Assert.assertEquals(8, resultadoSuma);
            Assert.assertEquals(-6, resultadoResta);
            Assert.assertEquals(7, resultadoMult);
            Assert.assertEquals(1/7, resultadoDiv);
        }
    }
}
